// link do gry: https://websamuraj.pl/examples/js/gra/ 
